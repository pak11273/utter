(window.webpackJsonp=window.webpackJsonp||[]).push([[107],{"6csj":function(e,a,t){"use strict";(function(e){var n;(n=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule)&&n(e),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule;a&&a(e)}();const r=[{value:"Brain Storm",label:"Brain Storm",className:"appHeader",disabled:!1},{value:"Chat",label:"General Chat",className:"appHeader",disabled:!1}],o=r;var s,l;a.a=o,(s=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default)&&s.register(r,"default","/var/www/html/utter/packages/client/src/data/appData.js"),(l=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule)&&l(e),function(){var e=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default;e&&(e.register(r,"_default","/var/www/html/utter/packages/client/src/data/appData.js"),e.register(o,"default","/var/www/html/utter/packages/client/src/data/appData.js"))}(),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule;a&&a(e)}()}).call(this,t("Ua1F")(e))},"7YX4":function(e,a,t){"use strict";(function(e){var n;t.d(a,"a",function(){return r}),(n=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule)&&n(e),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule;a&&a(e)}();const r=e=>({actions:{display:"flex",justifyContent:"flex-end"},appBar:{zIndex:e.zIndex.drawer+1},card2:{height:"370px",maxWidth:"300px",display:"flex",flexDirection:"column"},card:{backgroundColor:"red",minHeight:"240px",maxHeight:"240px",display:"flex",flexDirection:"column"},cardDescription:{height:"70px",lineHeight:"1em",overflow:"auto",wordBreak:"break-all"},cardGrid:{padding:`${8*e.spacing.unit}px 0`},cardMedia:{paddingTop:"56.25%","&:hover":{cursor:"pointer"}},cardContent:{flexGrow:1},cardTitle:{height:"54px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},cardTitle2:{height:"52px",lineHeight:"1.2em",overflow:"hidden",wordBreak:"break-word"},cardUsername:{whiteSpace:"nowrap",width:"200px",overflow:"hidden",textOverflow:"ellipsis"},content:{flexGrow:1,padding:3*e.spacing.unit},drawer:{width:240,flexShrink:0},drawerPaper:{width:240},formControl:{margin:e.spacing.unit,minWidth:120},heading:{color:"white"},heroUnit:{backgroundColor:e.palette.background.paper},heroUnitZoneCreate:{backgroundColor:"#502bae"},heroContentZoneCreate:{maxWidth:960,margin:"0 auto",padding:`${8*e.spacing.unit}px ${6*e.spacing.unit}px ${6*e.spacing.unit}px`},heroContent:{margin:"0 auto",padding:`${8*e.spacing.unit}px 0 ${6*e.spacing.unit}px`},heroButtons:{marginTop:4*e.spacing.unit},layout:{width:"auto",marginLeft:3*e.spacing.unit,marginRight:3*e.spacing.unit,[e.breakpoints.up(1240+3*e.spacing.unit*2)]:{width:1240,marginLeft:"auto",marginRight:"auto"}},root:{display:"flex",flexGrow:1,width:"100%"},rootZoneCreate:{maxWidth:960,margin:"0 auto"},saveButton:{margin:"50px"},select:{width:"80% !important",margin:"10px auto !important"},selectEmpty:{marginTop:2*e.spacing.unit},searchField:{marginTop:"7px"},showMore:{position:"absolute",bottom:-50,left:"50%",webkitTransform:"translateX(-50%)",transform:"translateX(-50%)",whiteSpace:"nowrap"},subHeading:{color:"black",marginTop:"40px",position:"relative"}});var o,s;(o=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default)&&(o.register(240,"drawerWidth","/var/www/html/utter/packages/client/src/layouts/zones/styles.js"),o.register(r,"styles","/var/www/html/utter/packages/client/src/layouts/zones/styles.js")),(s=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule)&&s(e),function(){var e=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default;e&&(e.register(240,"drawerWidth","/var/www/html/utter/packages/client/src/layouts/zones/styles.js"),e.register(r,"styles","/var/www/html/utter/packages/client/src/layouts/zones/styles.js"))}(),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule;a&&a(e)}()}).call(this,t("Ua1F")(e))},Knvs:function(e,a,t){"use strict";(function(e){var n,r=t("r0ML"),o=t.n(r),s=t("ZSWU"),l=t("Pc05"),i=t.n(l),c=t("5M77"),d=t.n(c),u=t("BZoD"),p=t.n(u),g=t("C5B4"),m=t.n(g),h=t("YvzW"),f=t.n(h),w=t("qvsH"),v=t("yVZo"),b=t.n(v),L=t("ketZ"),H=t.n(L),y=t("ctQ7"),z=t.n(y),E=t("GYe8"),x=t("18K1"),G=t("e+cM"),k=t("rf6I"),C=t("7YX4");(n=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule)&&n(e),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule;a&&a(e)}();const D=e=>{const a=a=>()=>{x.session.zone=a,e.history.push({pathname:`/zone/${a._id}`,state:{zoneeId:a.id}})},{data:t,error:n,loading:r,fetchMore:s}=Object(E.a)(k.a,{notifyOnNetworkStatusChange:!0,variables:{cursor:"",searchInput:e.search&&e.search.searchInput?e.search.searchInput:"",selectionBox:e.search&&e.search.selectionBox?e.search.selectionBox:"",app:e.search&&e.search.app?e.search.app:"",subscriptions:e.search&&e.search.subscriptions?e.search.subscriptions:"",usingLang:e.search&&e.search.usingLang?e.search.usingLang:"",teachingLang:e.search&&e.search.teachingLang?e.search.teachingLang:""}});if(n)return o.a.createElement(H.a,null,o.a.createElement("p",null,n.graphQLErrors.map(({message:e},a)=>o.a.createElement("p",{style:{fontSize:"1.3em",color:"red",margin:"30px",padding:"30px",textAlign:"center"},key:a},e))));const{classes:l}=e,c=()=>{alert("ALL public zones irregardless of age requirements are to uphold the following zone rules: \nNo discrimination \nNo sexual harrassment \nNo sexual innuendos of any kind \nNo Profanity \nNo Spamming Chat \n\nRule breakers are subject to suspensed or banned accounts.")};return o.a.createElement("div",null,o.a.createElement("div",{className:i()(l.layout,l.cardGrid)},o.a.createElement(H.a,{container:!0,spacing:8,style:{position:"relative"}},t.getZones&&t.getZones.zones.map((n,i)=>o.a.createElement(H.a,{item:!0,key:n._id,xs:12,sm:12,md:3,lg:2},o.a.createElement(d.a,{className:l.card2},o.a.createElement(m.a,{className:l.cardContent},o.a.createElement(z.a,{className:l.cardTitle2,gutterBottom:!0,variant:"h6",component:"h6"},n.zoneName),o.a.createElement(z.a,{className:l.cardDescription,gutterBottom:!0,component:"p"},n.zoneDescription),o.a.createElement(z.a,{className:l.cardUsername,gutterBottom:!0,variant:"caption"},"by: ",n.ownerCourse.username)),o.a.createElement("div",{style:{padding:"0 0 0 20px"}},"App: ",n.app),o.a.createElement("div",{style:{padding:"0 0 0 20px",marginRight:"20px",overflow:"hidden",whiteSpace:"nowrap"}},"Course: ",n.zoneCourse&&n.zoneCourse.title||""),o.a.createElement("div",{style:{padding:"0 0 0 20px"}},"Level: ",n&&n.courseLevel||""),o.a.createElement("div",{style:{padding:"0 0 0 20px"}},"Using:"," ",n.zoneCourse&&n.zoneCourse.usingLang||""),o.a.createElement("div",{style:{padding:"0 0 0 20px"}},"Teaching:"," ",n.zoneCourse&&n.zoneCourse.teachingLang||""),o.a.createElement("div",{style:{display:"flex",padding:"10px 0 0 20px"}},o.a.createElement(f.a,null),o.a.createElement("span",{style:{display:"flex",alignItems:"center",padding:"5px 25px 0px 5px"}},n.occupants&&n.occupants.length||1),o.a.createElement("span",{style:{display:"flex",alignItems:"center",paddingTop:"5px"}},"Max: 30")),o.a.createElement(p.a,{className:l.actions},o.a.createElement(b.a,{color:"secondary",size:"small",onClick:c,style:{margin:"10px 0"}},n.ageGroup),o.a.createElement(b.a,{onClick:a(n),size:"large",className:l.editButton},"ENTER"))),i===t.getZones.zones.length-1&&t.getZones.more&&o.a.createElement(G.p,{loading:r,disabled:r,className:e.classes.showMore,color:"secondary",variant:"contained",onClick:()=>s({variables:{cursor:t.getZones.zones[t.getZones.zones.length-1]._id},updateQuery:(e,{fetchMoreResult:a})=>a?{getZones:{...a.getZones,zones:[...e.getZones.zones,...a.getZones.zones]}}:e})},"Show More"))))))},N=Object(s.a)(Object(w.withStyles)(C.a)(D)),S=N;var $,j;a.a=S,($=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default)&&($.register(D,"ZonesGrid","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones-grid.js"),$.register(N,"default","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones-grid.js")),(j=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule)&&j(e),function(){var e=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default;e&&(e.register(D,"ZonesGrid","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones-grid.js"),e.register(N,"_default","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones-grid.js"),e.register(S,"default","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones-grid.js"))}(),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule;a&&a(e)}()}).call(this,t("Ua1F")(e))},bRYT:function(e,a,t){"use strict";t.r(a),function(e){var n,r=t("r0ML"),o=t.n(r),s=t("oO/2"),l=t("ZSWU"),i=t("h815"),c=t("hycj"),d=t("18K1"),u=t("WFJf"),p=t.n(u),g=t("Rgw4"),m=t.n(g),h=t("ketZ"),f=t.n(h),w=t("yPKP"),v=t.n(w),b=t("f7/k"),L=t.n(b),H=t("h3zv"),y=t.n(H),z=t("uUnX"),E=t.n(z),x=t("kued"),G=t.n(x),k=t("qvsH"),C=t("x0Wo"),D=t.n(C),N=t("ctQ7"),S=t.n(N),$=t("e+cM"),j=t("7YX4"),M=t("Knvs"),Q=t("h7VR"),Z=t("6csj");(n=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule)&&n(e),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule;a&&a(e)}();const B=e=>{delete d.session.zone;const{classes:a,handleChange:t,handleSubmit:n,values:r}=e;return o.a.createElement("form",{className:a.root,onSubmit:n,autoComplete:"off"},o.a.createElement(p.a,{className:a.drawer,variant:"permanent",classes:{paper:a.drawerPaper}},o.a.createElement($.s,{margin:"100px 0 0 0"}),o.a.createElement("div",{align:"center"},o.a.createElement(S.a,{variant:"h6",align:"center",gutterBottom:!0},"I speak:"),o.a.createElement(c.a,{name:"usingLang",component:$.x,options:Q.a}),o.a.createElement(S.a,{variant:"h6",align:"center",gutterBottom:!0},"I want to learn:"),o.a.createElement(c.a,{name:"teachingLang",component:$.z,options:Q.a}),o.a.createElement(S.a,{variant:"h6",align:"center",gutterBottom:!0},"Choose An App"),o.a.createElement(c.a,{name:"app",component:$.y,options:Z.a}),o.a.createElement($.s,{margin:"40px 0 0 0"}),o.a.createElement($.s,{margin:"40px 0 0 0"}),o.a.createElement($.s,{margin:"40px 0 0 0"}),o.a.createElement(D.a,null),o.a.createElement($.s,{margin:"40px 0 0 0"}),o.a.createElement(E.a,{component:s.a,to:"/zones/create"},o.a.createElement(S.a,{align:"center",gutterBottom:!0},"Host A Zone")))),o.a.createElement("main",{className:a.content},o.a.createElement(i.a,null,o.a.createElement("meta",{charset:"utf-8"}),o.a.createElement("meta",{name:"viewport",content:"width=device-width, initial-scale=1, shrink-to-fit=no"}),o.a.createElement("meta",{name:"description",content:"Find a zone.  Start uttering!"}),o.a.createElement("meta",{name:"author",content:"Isaac Pak"}),o.a.createElement("title",null,"Utterzone | Zones"),o.a.createElement("link",{rel:"canonical",href:"https://utterzone/zones"})),o.a.createElement("div",{className:a.heroUnit},o.a.createElement("div",{className:a.heroContent},o.a.createElement(f.a,{container:!0,justify:"center",direction:"column"},o.a.createElement(S.a,{variant:"h4",align:"center",gutterBottom:!0},"Enter a Zone"),o.a.createElement(f.a,{container:!0,alignItems:"center",justify:"center"},o.a.createElement(G.a,{name:"searchInput",id:"outlined-search",label:"Search",onChange:t,type:"search",className:a.searchField,value:r.searchInput,margin:"normal",variant:"outlined"}),o.a.createElement(m.a,{variant:"outlined",className:a.formControl},o.a.createElement(y.a,{value:r.selectionBox,name:"selectionBox",onChange:t,input:o.a.createElement(L.a,{labelWidth:0,name:"info",id:"outlined-filter-simple"})},o.a.createElement(v.a,{value:""},o.a.createElement("em",null,"None")),o.a.createElement(v.a,{value:"host"},"Host"),o.a.createElement(v.a,{value:"zoneName"},"Zone Name"))),o.a.createElement($.p,{variant:"contained",color:"secondary",type:"submit",size:"large",loading:e.status&&e.status.loading,disabled:e.status&&e.status.loading},"Search"))))),o.a.createElement(f.a,null,o.a.createElement(M.a,{search:e.status&&e.status.search}))))},I=Object(l.a)(Object(c.b)({validateOnChange:!1,validateOnBlur:!1,mapPropsToValues:()=>({app:"",subscriptions:"",searchInput:"",selectionBox:"",teachingLang:"",usingLang:""}),handleSubmit:async(e,{setStatus:a})=>{a({loading:!0}),a({search:{app:e.app,subscriptions:e.subscriptions,searchInput:e.searchInput,selectionBox:e.selectionBox,teachingLang:e.teachingLang,usingLang:e.usingLang}})}})(Object(k.withStyles)(j.a)(B))),T=I;var O,U;a.default=T,(O=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default)&&(O.register(B,"ZonesContainer","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones.js"),O.register(I,"default","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones.js")),(U=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule)&&U(e),function(){var e=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default;e&&(e.register(B,"ZonesContainer","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones.js"),e.register(I,"_default","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones.js"),e.register(T,"default","/var/www/html/utter/packages/client/src/layouts/zones/containers/zones.js"))}(),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule;a&&a(e)}()}.call(this,t("Ua1F")(e))},rf6I:function(e,a,t){"use strict";(function(e){t.d(a,"a",function(){return s}),t.d(a,"b",function(){return l});var n,r=t("ktN7"),o=t.n(r);(n=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule)&&n(e),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).enterModule;a&&a(e)}();const s=o.a`
  query getZones(
    $app: String
    $subscriptions: String
    $cursor: String
    $searchInput: String
    $selectionBox: String
    $teachingLang: String!
    $usingLang: String!
  ) {
    getZones(
      input: {
        app: $app
        subscriptions: $subscriptions
        cursor: $cursor
        searchInput: $searchInput
        selectionBox: $selectionBox
        teachingLang: $teachingLang
        usingLang: $usingLang
      }
    ) {
      cursor
      more
      zones {
        ageGroup
        app
        zoneCourse {
          title
          usingLang
          teachingLang
        }
        course {
          _id
        }
        courseLevel
        _id
        owner {
          _id
        }
        ownerCourse {
          _id
          username
        }
        teachingLang
        usingLang
        zoneDescription
        zoneImage
        zoneName
      }
    }
  }
`,l=o.a`
  mutation zoneCreate(
    $ageGroup: String!
    $app: String
    $course: String
    $courseLevel: String
    $owner: String!
    $zoneName: String!
    $zoneDescription: String
    $teachingLang: String
    $usingLang: String
  ) {
    zoneCreate(
      input: {
        ageGroup: $ageGroup
        app: $app
        course: $course
        courseLevel: $courseLevel
        owner: $owner
        zoneName: $zoneName
        zoneDescription: $zoneDescription
        teachingLang: $teachingLang
        usingLang: $usingLang
      }
    ) {
      _id
      app
      courseLevel
      ageGroup
      zoneName
      zoneDescription
      owner {
        username
      }
    }
  }
`;var i,c;(i=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default)&&(i.register(s,"GET_ZONES","/var/www/html/utter/packages/client/src/layouts/zones/zone-queries.js"),i.register(l,"ZONE_CREATE_MUTATION","/var/www/html/utter/packages/client/src/layouts/zones/zone-queries.js")),(c=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule)&&c(e),function(){var e=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).default;e&&(e.register(s,"GET_ZONES","/var/www/html/utter/packages/client/src/layouts/zones/zone-queries.js"),e.register(l,"ZONE_CREATE_MUTATION","/var/www/html/utter/packages/client/src/layouts/zones/zone-queries.js"))}(),function(){var a=("undefined"!=typeof reactHotLoaderGlobal?reactHotLoaderGlobal:t("DQwH")).leaveModule;a&&a(e)}()}).call(this,t("Ua1F")(e))}}]);
//# sourceMappingURL=bundle.107.7e85b4ec76b64fe0cc53.js.map