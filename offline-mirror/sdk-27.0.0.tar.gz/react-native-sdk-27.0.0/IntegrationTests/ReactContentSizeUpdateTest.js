/**
 * Copyright (c) 2015-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * @providesModule ReactContentSizeUpdateTest
 */
'use strict';

var React = require('react');
var createReactClass = require('create-react-class');
var ReactNative = require('react-native');
var RCTNativeAppEventEmitter = require('../Libraries/EventEmitter/RCTNativeAppEventEmitter');
var Subscribable = require('../Libraries/Components/Subscribable');
var TimerMixin = require('react-timer-mixin');

var { View } = ReactNative;

var { TestModule } = ReactNative.NativeModules;

var reactViewWidth = 101;
var reactViewHeight = 102;
var newReactViewWidth = 201;
var newReactViewHeight = 202;

var ReactContentSizeUpdateTest = createReactClass({
  displayName: 'ReactContentSizeUpdateTest',
  mixins: [Subscribable.Mixin,
           TimerMixin],

  UNSAFE_componentWillMount: function() {
    this.addListenerOn(
      RCTNativeAppEventEmitter,
      'rootViewDidChangeIntrinsicSize',
      this.rootViewDidChangeIntrinsicSize
    );
  },

  getInitialState: function() {
    return {
      height: reactViewHeight,
      width: reactViewWidth,
    };
  },

  updateViewSize: function() {
    this.setState({
      height: newReactViewHeight,
      width: newReactViewWidth,
    });
  },

  componentDidMount: function() {
    this.setTimeout(
      () => { this.updateViewSize(); },
      1000
    );
  },

  rootViewDidChangeIntrinsicSize: function(intrinsicSize) {
    if (intrinsicSize.height === newReactViewHeight && intrinsicSize.width === newReactViewWidth) {
      TestModule.markTestPassed(true);
    }
  },

  render() {
    return (
      <View style={{'height':this.state.height, 'width':this.state.width}}/>
    );
  }
});

ReactContentSizeUpdateTest.displayName = 'ReactContentSizeUpdateTest';

module.exports = ReactContentSizeUpdateTest;
